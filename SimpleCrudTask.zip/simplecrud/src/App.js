import './App.css';
import Usertable from './component/Usertable';
import { Grid } from '@mui/material';

function App() {
  return (
    <Grid>
      <Usertable />
    </Grid>
  );
}

export default App;